DAILYWINS SIMPLE FRONTEND PACKAGE

Navigation:
Home -> Register -> Verify Email -> Login -> Dashboard

The frontend includes:
- Country selection, country code and phone number
- Primary country currency display
- USD equivalent display areas
- Deposit receipt upload layout
- Withdrawal request layout
- KYC upload layout
- Pending / Approved / Declined status layouts
- Dashboard referral bonus summary
- Referral bonuses page
- Admin deposit/withdrawal/KYC review layouts
- Admin user-details page with manual profit controls
- Simple navigation paths and corrected page links

BACKEND/API CONNECTION REQUIRED FOR:
Actual email code sending/verification, secure authentication, file storage,
exchange rates, USD conversions, approval/decline processing, balances,
manual profit persistence, referral calculations, notifications and real admin authorization.
