
(function(){
 const K='dailywins_user';
 const state=()=>{try{return JSON.parse(localStorage.getItem(K)||'null')}catch(e){return null}};
 const save=u=>localStorage.setItem(K,JSON.stringify(u));
 const money=(n,u)=> (u?.symbol||'$')+Number(n||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
 const usd=(n,u)=> '$'+Number(n||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});

 document.addEventListener('DOMContentLoaded',()=>{
  const path=location.pathname.split('/').pop()||'index.html';
  const u=state();

  if(path==='register.html'){
   const form=document.querySelector('form');
   if(!form)return;
   let country=form.querySelector('[name="country"]');
   if(country && !country.dataset.ready){
    const countries=[
      ['NG','Nigeria','NGN','₦','+234'],['US','United States','USD','$','+1'],
      ['GB','United Kingdom','GBP','£','+44'],['AE','United Arab Emirates','AED ','AED ','+971'],
      ['CA','Canada','CAD','C$','+1'],['ZA','South Africa','ZAR','R','+27']
    ];
    country.innerHTML='';
    countries.forEach(x=>{let o=new Option(x[1],x[0]);o.dataset.currency=x[2];o.dataset.symbol=x[3];o.dataset.code=x[4];country.add(o)});
    country.dataset.ready='1';
   }
   let code=document.getElementById('countryCode'), phone=document.getElementById('phoneNumber');
   if(!code){
    const wrap=document.createElement('div'); wrap.className='field';
    wrap.innerHTML='<label>Phone Number</label><div style="display:flex;gap:8px"><input id="countryCode" readonly style="max-width:100px"><input id="phoneNumber" name="phone_number" type="tel" required placeholder="Phone number"></div>';
    form.insertBefore(wrap,form.querySelector('button[type="submit"]'));
    code=document.getElementById('countryCode'); phone=document.getElementById('phoneNumber');
   }
   function sync(){let o=country?.options[country.selectedIndex];if(!o)return;code.value=o.dataset.code||'';let c=document.getElementById('currencyInput');let s=document.getElementById('symbolInput');if(c)c.value=o.dataset.currency||'';if(s)s.value=o.dataset.symbol||''}
   country?.addEventListener('change',sync);sync();
   form.addEventListener('submit',e=>{
    e.preventDefault();
    const fd=new FormData(form),o=country?.options[country.selectedIndex];
    const user={email:(fd.get('email')||'').trim(),password:fd.get('password')||'',firstName:fd.get('first_name')||'User',
      country:o?.text||'',countryCode:o?.dataset.code||'',currency:o?.dataset.currency||'USD',symbol:o?.dataset.symbol||'$',
      phone:phone.value,verified:false,balance:0,usdBalance:0,profit:0,usdProfit:0,referralBonus:0,usdReferralBonus:0,totalReferrals:0,activeReferrals:0};
    save(user); location.href='verify-email.html';
   });
  }

  if(path==='verify-email.html'){
   document.getElementById('registeredEmail')?.append(u?.email||'');
   document.getElementById('confirmEmail')?.addEventListener('click',()=>{let x=state();if(x){x.verified=true;save(x);location.href='login.html'}});
  }

  if(path==='login.html'){
   const form=document.querySelector('form');
   if(form)form.addEventListener('submit',e=>{
    const x=state(); if(!x)return;
    const email=form.querySelector('[name="email"],[type="email"]'), pw=form.querySelector('[name="password"],[type="password"]');
    if(email&&pw){e.preventDefault(); if(x.verified&&email.value.trim()===x.email&&pw.value===x.password)location.href='dashboard.html'; else alert('Verify your email first or check your login details.');}
   });
  }

  if(['dashboard.html','deposit.html','withdraw.html','investments.html','transactions.html','referrals.html','notifications.html','kyc.html','profile.html','settings.html','support.html'].includes(path)){
   if(!u||!u.verified){location.href='login.html';return;}
   document.querySelectorAll('[data-money="balance"]').forEach(el=>el.textContent=money(u.balance,u));
   document.querySelectorAll('[data-usd="balance"]').forEach(el=>el.textContent=usd(u.usdBalance,u));
   document.querySelectorAll('[data-money="profit"]').forEach(el=>el.textContent=money(u.profit,u));
   document.querySelectorAll('[data-usd="profit"]').forEach(el=>el.textContent=usd(u.usdProfit,u));
   document.querySelectorAll('[data-money="referral"]').forEach(el=>el.textContent=money(u.referralBonus,u));
   document.querySelectorAll('[data-usd="referral"]').forEach(el=>el.textContent=usd(u.usdReferralBonus,u));
   document.querySelectorAll('[data-ref="total"]').forEach(el=>el.textContent=u.totalReferrals||0);
   document.querySelectorAll('[data-ref="active"]').forEach(el=>el.textContent=u.activeReferrals||0);
  }
 });
})();
